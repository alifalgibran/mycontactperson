package id.alif.mycontactperson

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import id.alif.mycontactperson.FirebaseUtil.FirestoreUtil
import kotlinx.android.synthetic.main.activity_add_contact.*

class AddContactActivity : AppCompatActivity() {
    var namaDepan: String=""
    var namaBelakang: String=""
    var no_telp: String=""
    var email1: String=""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_contact)

        namaDepan = nama_depan.text.toString()
        namaBelakang = nama_belakang.text.toString()
        no_telp = noTelp.text.toString()
        email1 = email.text.toString()

        simpan.setOnClickListener {
            FirestoreUtil.initCurrentUser(namaDepan, namaBelakang, no_telp, email1)
        }
    }
}
