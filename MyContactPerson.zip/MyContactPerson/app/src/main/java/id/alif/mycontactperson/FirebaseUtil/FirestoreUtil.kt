package id.alif.mycontactperson.FirebaseUtil

import android.content.Context
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FirebaseFirestore

object FirestoreUtil {
    private val firestoreInstance: FirebaseFirestore by lazy { FirebaseFirestore.getInstance() }

    private val currentUserDocRef: DocumentReference
        get() = firestoreInstance.document(
            "users"
        )

    fun initCurrentUser(namaDepan: String = "", namaBelakang: String = "",
                        noTelp: String = "", email:String = ""){

        val userFieldMap = mutableMapOf<String, Any>()
        if(namaDepan.isNotBlank()) userFieldMap["namaDepan"] = namaDepan
        if(namaBelakang.isNotBlank()) userFieldMap["namaBelakang"] = namaBelakang
        if(noTelp.isNotBlank()) userFieldMap["noTelp"] = noTelp
        if(email.isNotBlank()) userFieldMap["email"] = email

        currentUserDocRef.update(userFieldMap)
        }
}